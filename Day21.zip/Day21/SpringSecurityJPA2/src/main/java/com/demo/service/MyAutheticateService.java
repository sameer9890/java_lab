package com.demo.service;

import com.demo.beans.User;

public interface MyAutheticateService {

	void adduser(User user);

}
